//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: HT09_Linear_Vehicle_Model_types.h
//
// Code generated for Simulink model 'HT09_Linear_Vehicle_Model'.
//
// Model version                  : 2.17
// Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
// C/C++ source code generated on : Tue Nov  5 20:01:12 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-A (64-bit)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef HT09_Linear_Vehicle_Model_types_h_
#define HT09_Linear_Vehicle_Model_types_h_
#endif                                 // HT09_Linear_Vehicle_Model_types_h_

//
// File trailer for generated code.
//
// [EOF]
//
