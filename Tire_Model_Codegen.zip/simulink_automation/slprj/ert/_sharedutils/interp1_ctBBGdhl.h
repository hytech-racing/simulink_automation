//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: interp1_ctBBGdhl.h
//
// Code generated for Simulink model 'Tire_Model_Codegen'.
//
// Model version                  : 1.32
// Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
// C/C++ source code generated on : Tue Nov  5 20:01:42 2024
//
#ifndef interp1_ctBBGdhl_h_
#define interp1_ctBBGdhl_h_
#include "rtwtypes.h"

extern real_T interp1_ctBBGdhl(const real_T varargin_1[100], const real_T
  varargin_2[100], real_T varargin_3);

#endif                                 // interp1_ctBBGdhl_h_

//
// File trailer for generated code.
//
// [EOF]
//
